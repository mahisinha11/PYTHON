from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time

# Step 1: Launch Chrome Browser
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
driver.maximize_window()

# Step 2: Open Facebook
driver.get("https://www.facebook.com/")
time.sleep(3)

# Step 3: Login to Facebook
email = driver.find_element(By.ID, "email")
password = driver.find_element(By.ID, "pass")

email.send_keys("your_email_here")      # 👈 replace with your Facebook email
password.send_keys("your_password_here")  # 👈 replace with your Facebook password
password.send_keys(Keys.ENTER)

time.sleep(10)  # wait for login

# Step 4: Click on Create Post text area
post_box = driver.find_element(By.XPATH, "//div[@role='textbox']")
post_box.click()
time.sleep(3)

# Step 5: Write Blog / Post Content
post_box.send_keys(
    "Hello Everyone 👋\n\n"
    "This blog is posted automatically using Selenium Automation.\n"
    "Python + Selenium makes automation easy 🚀\n\n"
    "#Automation #Selenium #Python"
)

time.sleep(3)

# Step 6: Click Post Button
post_button = driver.find_element(By.XPATH, "//div[@aria-label='Post']")
post_button.click()

time.sleep(5)
print("Post published successfully!")

# Step 7: Close Browser
driver.quit()
