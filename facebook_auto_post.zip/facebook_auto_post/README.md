Project Title: Facebook Auto Blog Poster using Selenium

Module: 24 – Automation using Selenium
Language: Python
Tool: Selenium WebDriver
Browser: Google Chrome

Description:
This project demonstrates automation using Selenium in Python.
The script automatically opens Facebook, logs in with user credentials,
creates a blog/post, and publishes it on the Facebook timeline.

Files Included:
1. facebook_post.py – Python script for Facebook auto post automation
2. requirements.txt – List of required Python libraries
3. README.md – Project description and usage instructions

Steps to Run the Project:
1. Install Python 3.12 on the system.
2. Install required libraries using:
   pip install -r requirements.txt
3. Open the project folder in VS Code.
4. Edit facebook_post.py and enter Facebook login credentials.
5. Run the script using:
   python facebook_post.py
6. Chrome browser will open automatically and post will be published.

Output:
Facebook blog/post is successfully posted automatically using Selenium automation.

Note:
- Use a test Facebook account.
- Internet connection is required.
- Facebook UI may change, so XPath may need modification.
