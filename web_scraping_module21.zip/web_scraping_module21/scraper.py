print('PROGRAM STARTED')
import requests
from bs4 import BeautifulSoup
import pandas as pd

# Step 1: Website URL
url = "https://quotes.toscrape.com/"

# Step 2: Send request
response = requests.get(url)

# Step 3: Parse HTML
soup = BeautifulSoup(response.text, "html.parser")

# Step 4: Find quotes
quotes = soup.find_all("div", class_="quote")

data = []

for quote in quotes:
    text = quote.find("span", class_="text").text
    author = quote.find("small", class_="author").text
    data.append([text, author])

# Step 5: Save to CSV
df = pd.DataFrame(data, columns=["Quote", "Author"])
df.to_csv("quotes.csv", index=False)

print("Scraping completed! Data saved in quotes.csv")
print('PROGRAM ENDED')