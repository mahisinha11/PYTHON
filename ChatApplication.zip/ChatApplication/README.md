# Python Socket Chat Application

## Description
This project demonstrates a simple chat application using Python socket programming.
The application uses TCP protocol for reliable communication between client and server.

## Files
- server.py : Server-side program
- client.py : Client-side program

## How to Run
1. Open terminal and run server.py
2. Open another terminal and run client.py
3. Start chatting between client and server

## Module
Python Course - Module 26 (Network Programming)

## Output
Two-way text communication between server and client.
